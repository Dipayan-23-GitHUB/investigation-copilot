# Dashboard integration fix

Apply this patch at the repository root on top of the latest `main` branch.

## What it fixes

- Registers the existing authenticated Controller router, making `GET /api/v1/controller/dashboard` reachable.
- Connects `GET /api/v1/market/dashboard` to the low-cost public-data adapter (FRED/EIA + World Bank Pink Sheet), while retaining the Alpha Vantage search, equity-history and metals endpoints.
- Generates and includes the synthetic Controller fixture from the bundled fictional Source Ledger workbooks.
- Keeps uploaded Finance Reporting Pack data as the first choice. Only when no finance pack exists does the frontend request the clearly labelled synthetic Controller data.
- No database migration or new environment variable is required.

## Apply and test

```bash
unzip -o Investigation_Copilot_Dashboard_Integration_Fix.zip -d .
python -m compileall -q app scripts tests
pytest -q
```

Expected local test result: `25 passed`.

If tests pass:

```bash
git add APPLY_DASHBOARD_INTEGRATION_FIX.md app/main.py app/routers/market.py app/data/demo_finance.json frontend_reference/investigation_copilot.html
git commit -m "Wire Controller demo and public market dashboards"
git push origin main
```

Render must finish deploying the pushed commit before the live site changes.

## Data limitations

Controller fallback figures are synthetic examples for fictional Meridian Bicycle Co. They are not customer actuals and are not suitable for management, audit, tax, statutory, credit or external reporting. A successfully loaded customer Finance Reporting Pack takes precedence.

The market adapter intentionally does not invent Dow, S&P 500, Nasdaq Composite, VIX or ICE DXY observations. The USD series is the Federal Reserve broad trade-weighted index, not DXY. Gold and silver are monthly World Bank averages; Brent and broad USD are daily reference observations. Values may be delayed and are not trading quotes.
